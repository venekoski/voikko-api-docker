#!/usr/bin/env python
# -*- coding: utf-8 -*-
from libvoikko import Voikko

AUTHOR = 'Viljami Venekoski'
AUTHOR_EMAIL = "venekoski@gmail.com"
VERSION = '0.1'
VOIKKO = Voikko("fi")